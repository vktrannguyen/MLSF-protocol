grep '0.000 ' PPARA-OTS-actives-docked-Smina.txt >& actives-result.txt
grep '0.000 ' PPARA-OTS-inactives-docked-Smina.txt >& inactives-result.txt
grep '^CHEMBL' PPARA-OTS-actives-docked.mol2 >& actives-ID.txt
grep '^CHEMBL' PPARA-OTS-inactives-docked.mol2 >& inactives-ID.txt
cat actives-ID.txt inactives-ID.txt >& all-ID.txt
sed -i 's/0.000/Active/g' actives-result.txt
sed -i 's/0.000/Inactive/g' inactives-result.txt
awk '{print $2}' actives-result.txt >& actives-score.txt
awk '{print $2}' inactives-result.txt >& inactives-score.txt
cat actives-score.txt inactives-score.txt >& all-score.txt
awk '{print $3}' actives-result.txt >& actives-label.txt
awk '{print $3}' inactives-result.txt >& inactives-label.txt
cat actives-label.txt inactives-label.txt >& all-label.txt
paste all-ID.txt all-score.txt all-label.txt >& hit-list.txt
rm actives*txt inactives*txt all*txt
