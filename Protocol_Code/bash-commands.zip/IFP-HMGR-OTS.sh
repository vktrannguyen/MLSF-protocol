grep '^735' HMGR-OTS-actives-docked-IFP.txt | sed -n '4,$ p' >& actives-result.txt
grep '^735' HMGR-OTS-inactives-docked-IFP.txt | sed -n '4,$ p' >& inactives-result.txt
awk '{print $1}' actives-result.txt >& actives-label.txt
sed -i 's/735/Active/g' actives-label.txt
awk '{print $1}' inactives-result.txt >& inactives-label.txt
sed -i 's/735/Inactive/g' inactives-label.txt
cat actives-result.txt inactives-result.txt >& all-result.txt
cat actives-label.txt inactives-label.txt >& all-label.txt
paste all-result.txt all-label.txt >& hit-list.txt
rm actives*txt inactives*txt all*txt
