grep '^735' PPARA-DEKOIS-actives-docked-IFP.txt | sed -n '4,$ p' >& actives-result.txt
grep '^735' PPARA-DEKOIS-decoys-docked-IFP.txt | sed -n '4,$ p' >& decoys-result.txt
awk '{print $1}' actives-result.txt >& actives-label.txt
sed -i 's/735/Active/g' actives-label.txt
awk '{print $1}' decoys-result.txt >& decoys-label.txt
sed -i 's/735/Inactive/g' decoys-label.txt
cat actives-result.txt decoys-result.txt >& all-result.txt
cat actives-label.txt decoys-label.txt >& all-label.txt
paste all-result.txt all-label.txt >& hit-list.txt
rm actives*txt decoys*txt all*txt
