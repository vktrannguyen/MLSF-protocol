grep 'CNNscore' HMGR-OTS-actives-docked-CNN.txt >& actives-result.txt
grep 'CNNscore' HMGR-OTS-inactives-docked-CNN.txt >& inactives-result.txt
awk 'f{print;f=0} /@<TRIPOS>MOLECULE/{f=1}' HMGR-OTS-actives-docked.mol2 >& actives-ID.txt
awk 'f{print;f=0} /@<TRIPOS>MOLECULE/{f=1}' HMGR-OTS-inactives-docked.mol2 >& inactives-ID.txt
cat actives-ID.txt inactives-ID.txt >& all-ID.txt
sed -i 's/CNNscore:/Active/g' actives-result.txt
sed -i 's/CNNscore:/Inactive/g' inactives-result.txt
awk '{print $2}' actives-result.txt >& actives-score.txt
awk '{print $2}' inactives-result.txt >& inactives-score.txt
cat actives-score.txt inactives-score.txt >& all-score.txt
awk '{print $1}' actives-result.txt >& actives-label.txt
awk '{print $1}' inactives-result.txt >& inactives-label.txt
cat actives-label.txt inactives-label.txt >& all-label.txt
paste all-ID.txt all-score.txt all-label.txt >& hit-list.txt
rm actives*txt inactives*txt all*txt
