awk 'f{print;f=0} /RF/{f=1}' HMGR-OTS-actives-docked.sdf >& actives-score.txt
awk 'f{print;f=0} /RF/{f=1}' HMGR-OTS-inactives-docked.sdf >& inactives-score.txt
cat actives-score.txt inactives-score.txt >& all-score.txt
awk 'f{print;f=0} /@<TRIPOS>MOLECULE/{f=1}' HMGR-OTS-actives-docked.mol2 >& actives-ID.txt
awk 'f{print;f=0} /@<TRIPOS>MOLECULE/{f=1}' HMGR-OTS-inactives-docked.mol2 >& inactives-ID.txt
cat actives-ID.txt inactives-ID.txt >& all-ID.txt
grep '>  <RFScoreVS_v2>' HMGR-OTS-actives-docked.sdf >& actives-label.txt
sed -i 's/>  <RFScoreVS_v2>/Active/g' actives-label.txt
grep '>  <RFScoreVS_v2>' HMGR-OTS-inactives-docked.sdf >& inactives-label.txt
sed -i 's/>  <RFScoreVS_v2>/Inactive/g' inactives-label.txt
cat actives-label.txt inactives-label.txt >& all-label.txt
paste all-ID.txt all-score.txt all-label.txt >& hit-list.txt
rm actives*txt inactives*txt all*txt
