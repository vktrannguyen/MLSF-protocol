awk 'f{print;f=0} /RF/{f=1}' HMGR-DEKOIS-actives-docked.sdf >& actives-score.txt
awk 'f{print;f=0} /RF/{f=1}' HMGR-DEKOIS-decoys-docked.sdf >& decoys-score.txt
cat actives-score.txt decoys-score.txt >& all-score.txt
grep '^CHEMBL' HMGR-DEKOIS-actives-docked.mol2 >& actives-ID.txt
grep '^CHEMBL' HMGR-DEKOIS-decoys-docked.mol2 >& decoys-ID.txt
cat actives-ID.txt decoys-ID.txt >& all-ID.txt
grep '>  <RFScoreVS_v2>' HMGR-DEKOIS-actives-docked.sdf >& actives-label.txt
sed -i 's/>  <RFScoreVS_v2>/Active/g' actives-label.txt
grep '>  <RFScoreVS_v2>' HMGR-DEKOIS-decoys-docked.sdf >& decoys-label.txt
sed -i 's/>  <RFScoreVS_v2>/Inactive/g' decoys-label.txt
cat actives-label.txt decoys-label.txt >& all-label.txt
paste all-ID.txt all-score.txt all-label.txt >& hit-list.txt
rm actives*txt decoys*txt all*txt
