grep 'CNNscore' HMGR-DEKOIS-actives-docked-CNN.txt >& actives-result.txt
grep 'CNNscore' HMGR-DEKOIS-decoys-docked-CNN.txt >& decoys-result.txt
grep '^BDB' HMGR-DEKOIS-actives-docked.mol2 >& actives-ID.txt
grep '^ZINC' HMGR-DEKOIS-decoys-docked.mol2 >& decoys-ID.txt
cat actives-ID.txt decoys-ID.txt >& all-ID.txt
sed -i 's/CNNscore:/Active/g' actives-result.txt
sed -i 's/CNNscore:/Inactive/g' decoys-result.txt
awk '{print $2}' actives-result.txt >& actives-score.txt
awk '{print $2}' decoys-result.txt >& decoys-score.txt
cat actives-score.txt decoys-score.txt >& all-score.txt
awk '{print $1}' actives-result.txt >& actives-label.txt
awk '{print $1}' decoys-result.txt >& decoys-label.txt
cat actives-label.txt decoys-label.txt >& all-label.txt
paste all-ID.txt all-score.txt all-label.txt >& hit-list.txt
rm actives*txt decoys*txt all*txt
